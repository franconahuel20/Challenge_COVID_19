Sr Data Engineer Challenge - Covid-19 (Kaggle)
================================================

This ZIP contains:
- parquet_spark/: Parquet outputs generated with Spark using an RDD-based CSV read.
- parquet_pandas/: Parquet outputs generated with Pandas.
- state/: Delta control state (seen row key hashes) so each run processes only novelties.

Key design notes:
- Type enforcement is done at the last layer before writing Parquet.
- Delta logic uses a SHA-256 hash of a composite key per dataset.
- Runs are append-only for delta records; state is overwritten with the merged set of keys.
